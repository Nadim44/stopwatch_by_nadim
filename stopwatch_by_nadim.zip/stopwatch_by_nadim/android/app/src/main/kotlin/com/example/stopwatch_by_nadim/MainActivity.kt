package com.example.stopwatch_by_nadim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
